require('dotenv').config();
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const store = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PIN = process.env.ADMIN_PIN || 'DH2024';
const SESSION_SECRET = process.env.SESSION_SECRET || 'dh_sorteios_secret_change_me';

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
}));

function getClientIp(req) {
  return (req.headers['x-forwarded-for'] || '').split(',')[0].trim() ||
         req.headers['x-real-ip'] ||
         req.connection?.remoteAddress ||
         req.socket?.remoteAddress ||
         '0.0.0.0';
}

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Não autenticado. Faça login.' });
  next();
}

// ========== AUTH ==========
app.post('/api/register', (req, res) => {
  try {
    const db = store.get();
    const { username, password, displayName } = req.body;
    if (!username || !password || username.length < 3 || password.length < 4) {
      return res.status(400).json({ error: 'Usuário (min 3) e senha (min 4) são obrigatórios.' });
    }
    const cleanUser = username.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (cleanUser.length < 3) return res.status(400).json({ error: 'Nome de usuário inválido.' });
    if (db.users.find(u => u.username === cleanUser)) {
      return res.status(400).json({ error: 'Este usuário já existe.' });
    }

    const user = {
      id: db.nextIds.user++,
      username: cleanUser,
      password_hash: bcrypt.hashSync(password, 10),
      display_name: displayName || cleanUser,
      created_at: new Date().toISOString(),
      last_login: null,
      points: 0,
      is_admin: 0
    };
    db.users.push(user);

    db.messages.push({
      id: db.nextIds.message++,
      user_id: user.id,
      sender: 'DH SORTEIOS',
      subject: 'Bem-vindo ao DH SORTEIOS!',
      content: `Olá ${user.display_name}! 🎮\n\nBem-vindo à melhor plataforma de sorteios de contas de jogos!\n\nParticipe dos sorteios, ganhe contas e aproveite.\n\nBoa sorte!`,
      is_read: 0,
      is_prize: 0,
      created_at: new Date().toISOString()
    });

    store.save();
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.displayName = user.display_name;
    req.session.isAdmin = 0;

    res.json({ success: true, user: { id: user.id, username: user.username, displayName: user.display_name } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao registrar.' });
  }
});

app.post('/api/login', (req, res) => {
  try {
    const db = store.get();
    const { username, password } = req.body;
    const user = db.users.find(u => u.username === (username || '').trim().toLowerCase());
    if (!user || !bcrypt.compareSync(password, user.password_hash)) {
      return res.status(401).json({ error: 'Usuário ou senha incorretos.' });
    }
    user.last_login = new Date().toISOString();
    store.save();

    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.displayName = user.display_name;
    req.session.isAdmin = user.is_admin;

    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        displayName: user.display_name,
        isAdmin: !!user.is_admin,
        points: user.points
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'Erro no login.' });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/me', (req, res) => {
  if (!req.session.userId) return res.json({ authenticated: false });
  const db = store.get();
  const user = db.users.find(u => u.id === req.session.userId);
  if (!user) {
    req.session.destroy();
    return res.json({ authenticated: false });
  }
  const participations = db.participations.filter(p => p.user_id === user.id).length;
  const wins = db.sorteios.filter(s => s.winner_id === user.id).length;
  res.json({
    authenticated: true,
    user: {
      id: user.id,
      username: user.username,
      displayName: user.display_name,
      points: user.points,
      isAdmin: !!user.is_admin,
      createdAt: user.created_at,
      stats: { participations, wins }
    }
  });
});

// ========== SORTEIOS ==========
app.get('/api/sorteios', (req, res) => {
  const db = store.get();
  let myParts = [];
  if (req.session.userId) {
    myParts = db.participations.filter(p => p.user_id === req.session.userId).map(p => p.sorteio_id);
  }
  const list = db.sorteios
    .map(s => {
      const winner = s.winner_id ? db.users.find(u => u.id === s.winner_id) : null;
      return {
        ...s,
        participants_count: db.participations.filter(p => p.sorteio_id === s.id).length,
        winner_username: winner ? winner.username : null,
        already_participated: myParts.includes(s.id)
      };
    })
    .sort((a, b) => {
      if (a.status === 'active' && b.status !== 'active') return -1;
      if (b.status === 'active' && a.status !== 'active') return 1;
      return new Date(b.created_at) - new Date(a.created_at);
    });
  res.json({ sorteios: list });
});

app.get('/api/sorteios/:id', (req, res) => {
  const db = store.get();
  const s = db.sorteios.find(x => x.id === parseInt(req.params.id));
  if (!s) return res.status(404).json({ error: 'Sorteio não encontrado.' });
  const winner = s.winner_id ? db.users.find(u => u.id === s.winner_id) : null;
  let already = false;
  if (req.session.userId) {
    already = !!db.participations.find(p => p.user_id === req.session.userId && p.sorteio_id === s.id);
  }
  res.json({
    ...s,
    participants_count: db.participations.filter(p => p.sorteio_id === s.id).length,
    winner_username: winner ? winner.username : null,
    already_participated: already
  });
});

app.post('/api/sorteios/:id/participate', requireAuth, (req, res) => {
  try {
    const db = store.get();
    const sorteioId = parseInt(req.params.id);
    const userId = req.session.userId;
    const ip = getClientIp(req);

    const sorteio = db.sorteios.find(s => s.id === sorteioId);
    if (!sorteio) return res.status(404).json({ error: 'Sorteio não encontrado.' });
    if (sorteio.status !== 'active') return res.status(400).json({ error: 'Este sorteio já foi encerrado.' });

    if (db.participations.find(p => p.user_id === userId && p.sorteio_id === sorteioId)) {
      return res.status(400).json({ error: 'Você já participou deste sorteio com esta conta.' });
    }
    if (db.participations.find(p => p.ip_address === ip && p.sorteio_id === sorteioId)) {
      return res.status(400).json({ error: 'Este IP já participou deste sorteio. Você só pode participar 1 vez por IP. Use outro dispositivo/rede para participar novamente.' });
    }

    db.participations.push({
      id: db.nextIds.participation++,
      user_id: userId,
      sorteio_id: sorteioId,
      ip_address: ip,
      created_at: new Date().toISOString()
    });

    const user = db.users.find(u => u.id === userId);
    if (user) user.points = (user.points || 0) + 10;

    db.messages.push({
      id: db.nextIds.message++,
      user_id: userId,
      sender: 'Sistema',
      subject: 'Participação confirmada!',
      content: `Você entrou no sorteio: ${sorteio.title}\nBoa sorte! 🍀`,
      is_read: 0,
      is_prize: 0,
      created_at: new Date().toISOString()
    });

    store.save();
    res.json({ success: true, message: 'Participação registrada com sucesso! Boa sorte!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao participar.' });
  }
});

// ========== INBOX ==========
app.get('/api/inbox', requireAuth, (req, res) => {
  const db = store.get();
  const messages = db.messages
    .filter(m => m.user_id === req.session.userId)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .slice(0, 100);
  const unread = messages.filter(m => !m.is_read).length;
  res.json({ messages, unread });
});

app.post('/api/inbox/:id/read', requireAuth, (req, res) => {
  const db = store.get();
  const m = db.messages.find(x => x.id === parseInt(req.params.id) && x.user_id === req.session.userId);
  if (m) { m.is_read = 1; store.save(); }
  res.json({ success: true });
});

app.delete('/api/inbox/:id', requireAuth, (req, res) => {
  const db = store.get();
  const idx = db.messages.findIndex(x => x.id === parseInt(req.params.id) && x.user_id === req.session.userId);
  if (idx >= 0) { db.messages.splice(idx, 1); store.save(); }
  res.json({ success: true });
});

// ========== ADMIN ==========
app.post('/api/admin/verify-pin', requireAuth, (req, res) => {
  if (req.body.pin === ADMIN_PIN) {
    req.session.adminPinVerified = true;
    const db = store.get();
    const user = db.users.find(u => u.id === req.session.userId);
    if (user) { user.is_admin = 1; store.save(); }
    req.session.isAdmin = 1;
    return res.json({ success: true, message: 'PIN correto. Acesso admin liberado.' });
  }
  res.status(403).json({ error: 'PIN incorreto.' });
});

app.post('/api/admin/sorteios', requireAuth, (req, res) => {
  if (!req.session.isAdmin && !req.session.adminPinVerified) {
    return res.status(403).json({ error: 'Acesso admin necessário. Verifique o PIN.' });
  }
  const db = store.get();
  const { title, description, prize_name, prize_details, ends_at, image_url } = req.body;
  if (!title || !prize_name) return res.status(400).json({ error: 'Título e nome do prêmio são obrigatórios.' });

  const s = {
    id: db.nextIds.sorteio++,
    title,
    description: description || '',
    prize_name,
    prize_details: prize_details || '',
    image_url: image_url || null,
    status: 'active',
    max_participants: 0,
    ends_at: ends_at || null,
    created_at: new Date().toISOString(),
    created_by: req.session.userId,
    winner_id: null,
    drawn_at: null
  };
  db.sorteios.push(s);
  store.save();
  res.json({ success: true, id: s.id, message: 'Sorteio criado com sucesso!' });
});

app.post('/api/admin/sorteios/:id/draw', requireAuth, (req, res) => {
  if (!req.session.isAdmin && !req.session.adminPinVerified) {
    return res.status(403).json({ error: 'Acesso admin necessário.' });
  }
  const db = store.get();
  const sorteioId = parseInt(req.params.id);
  const { prize_details } = req.body;

  const sorteio = db.sorteios.find(s => s.id === sorteioId);
  if (!sorteio) return res.status(404).json({ error: 'Sorteio não encontrado.' });
  if (sorteio.status === 'drawn') return res.status(400).json({ error: 'Sorteio já foi sorteado.' });

  const participants = db.participations.filter(p => p.sorteio_id === sorteioId);
  if (participants.length === 0) return res.status(400).json({ error: 'Nenhum participante neste sorteio.' });

  const winnerPart = participants[Math.floor(Math.random() * participants.length)];
  const winnerId = winnerPart.user_id;
  const finalDetails = prize_details || sorteio.prize_details || 'Detalhes do prêmio serão enviados em breve.';

  sorteio.status = 'drawn';
  sorteio.winner_id = winnerId;
  sorteio.drawn_at = new Date().toISOString();
  sorteio.prize_details = finalDetails;

  const winner = db.users.find(u => u.id === winnerId);
  if (winner) winner.points = (winner.points || 0) + 100;

  const content = `🎉 PARABÉNS! Você ganhou o sorteio: ${sorteio.title}\n\n` +
    `Prêmio: ${sorteio.prize_name}\n\n` +
    `📱 Sua conta já foi enviada!\n\n` +
    `${finalDetails}\n\n` +
    `Verifique seu login e entre normalmente.\nAproveite seu prêmio! 🔥\n\n` +
    `— DH SORTEIOS`;

  db.messages.push({
    id: db.nextIds.message++,
    user_id: winnerId,
    sender: 'DH SORTEIOS',
    subject: `Parabéns! Você ganhou: ${sorteio.prize_name}`,
    content,
    is_read: 0,
    is_prize: 1,
    created_at: new Date().toISOString()
  });

  store.save();
  res.json({
    success: true,
    winner: { id: winnerId, username: winner.username, displayName: winner.display_name },
    participants: participants.length,
    message: `Ganhador sorteado: ${winner.display_name || winner.username}`
  });
});

app.get('/api/admin/sorteios', requireAuth, (req, res) => {
  if (!req.session.isAdmin && !req.session.adminPinVerified) {
    return res.status(403).json({ error: 'Acesso admin necessário.' });
  }
  const db = store.get();
  const list = db.sorteios.map(s => {
    const winner = s.winner_id ? db.users.find(u => u.id === s.winner_id) : null;
    return {
      ...s,
      participants_count: db.participations.filter(p => p.sorteio_id === s.id).length,
      winner_username: winner ? winner.username : null
    };
  }).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  res.json({ sorteios: list });
});

app.get('/api/ranking', (req, res) => {
  const db = store.get();
  const ranking = db.users
    .map(u => ({
      id: u.id,
      username: u.username,
      display_name: u.display_name,
      points: u.points || 0,
      wins: db.sorteios.filter(s => s.winner_id === u.id).length
    }))
    .sort((a, b) => b.points - a.points || b.wins - a.wins)
    .slice(0, 20);
  res.json({ ranking });
});

app.get('/api/historico', requireAuth, (req, res) => {
  const db = store.get();
  const historico = db.participations
    .filter(p => p.user_id === req.session.userId)
    .map(p => {
      const s = db.sorteios.find(x => x.id === p.sorteio_id);
      return {
        participated_at: p.created_at,
        id: s?.id,
        title: s?.title,
        prize_name: s?.prize_name,
        status: s?.status,
        winner_id: s?.winner_id,
        i_won: s?.winner_id === req.session.userId ? 1 : 0
      };
    })
    .sort((a, b) => new Date(b.participated_at) - new Date(a.participated_at));
  res.json({ historico });
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🚀 DH SORTEIOS rodando em http://localhost:${PORT}`);
  console.log(`📌 Admin PIN padrão: ${ADMIN_PIN}`);
  console.log(`👤 Admin padrão: admin / admin123\n`);
});
