# 🎮 DH SORTEIOS

Plataforma profissional de sorteios de contas de jogos (Free Fire, Roblox, etc).

Tema gamer azul/neon, com logo DH, banner, caixa de entrada privada para entrega de prêmios, restrição de 1 participação por IP e painel admin protegido por PIN.

## ✨ Funcionalidades

- Cadastro e login de usuários
- Participação em sorteios (1x por conta + 1x por IP)
- Caixa de Entrada privada: quando ganha, a conta/prêmio chega direto no PV do usuário
- Ranking de pontos
- Histórico de participações
- Painel Admin (PIN): criar sorteios e sortear ganhadores
- Design 100% gamer profissional (azul neon + imagens oficiais)

## 🚀 Como rodar localmente (versão de teste no Chrome)

```bash
# 1. Entre na pasta
cd dh-sorteios

# 2. Instale as dependências
npm install

# 3. Inicie o servidor
npm start
```

Abra no Chrome: **http://localhost:3000**

**Login admin padrão:**
- Usuário: `admin`
- Senha: `admin123`
- PIN Admin (para criar/sortear): `DH2024`

## 📦 Colocar no GitHub

```bash
# Na pasta do projeto
cd dh-sorteios

# Inicializa git
git init
git add .
git commit -m "DH Sorteios - versão inicial profissional"

# Crie um repositório vazio no GitHub (sem README)
# Depois:
git remote add origin https://github.com/SEU_USUARIO/dh-sorteios.git
git branch -M main
git push -u origin main
```

## 🌐 Deploy no Render (gratuito)

1. Acesse [https://render.com](https://render.com) e faça login com GitHub
2. Clique em **New +** → **Web Service**
3. Conecte o repositório `dh-sorteios`
4. Configure:
   - **Name:** dh-sorteios
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free
5. Em **Environment** adicione:
   - `ADMIN_PIN` = seu PIN secreto (ex: DH2024)
   - `SESSION_SECRET` = uma string longa aleatória
   - `NODE_ENV` = production
6. Clique em **Create Web Service**

Pronto! O Render vai gerar uma URL tipo `https://dh-sorteios.onrender.com`

> **Nota:** No plano free do Render o disco é efêmero. Os dados (usuários/sorteios) resetam se o serviço dormir muito tempo. Para produção real use um banco externo (PostgreSQL no próprio Render ou MongoDB Atlas).

## 🔒 Segurança do Admin

- Só quem digita o **PIN correto** consegue criar sorteios e sortear.
- O PIN fica no arquivo `.env` (não sobe pro GitHub se você criar `.gitignore`).

Crie um `.gitignore`:

```
node_modules/
data/
.env
*.log
```

## 📁 Estrutura

```
dh-sorteios/
├── public/
│   ├── images/
│   │   ├── logo.jpg          # Logo circular DH
│   │   └── banner.jpg        # Banner com Rio + DH SORTEIO
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── data/                     # Banco JSON (criado automaticamente)
├── db.js
├── server.js
├── package.json
├── .env.example
└── README.md
```

## 🛠️ Comandos úteis

```bash
# Desenvolvimento
npm start

# Ver logs
# (o servidor imprime a URL e o PIN)

# Resetar banco (apaga todos os dados)
rm -rf data/
npm start
```

Feito com 💙 para a comunidade gamer.
