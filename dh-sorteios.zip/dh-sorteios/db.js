const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const defaultData = {
  users: [],
  sorteios: [],
  participations: [],
  messages: [],
  nextIds: { user: 1, sorteio: 1, participation: 1, message: 1 }
};

function load() {
  try {
    if (fs.existsSync(DB_FILE)) {
      return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    }
  } catch (e) {}
  return JSON.parse(JSON.stringify(defaultData));
}

function save(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

let db = load();

// Seed if empty
if (db.users.length === 0) {
  const hash = bcrypt.hashSync('admin123', 10);
  db.users.push({
    id: db.nextIds.user++,
    username: 'admin',
    password_hash: hash,
    display_name: 'Administrador',
    created_at: new Date().toISOString(),
    last_login: null,
    points: 0,
    is_admin: 1
  });
  db.sorteios.push({
    id: db.nextIds.sorteio++,
    title: 'Sorteio Conta Free Fire - Diamante',
    description: 'Participe e concorra a uma conta Free Fire nível alto com skins exclusivas!',
    prize_name: 'Conta Free Fire',
    prize_details: 'Login e senha serão enviados na Caixa de Entrada do ganhador.',
    image_url: null,
    status: 'active',
    max_participants: 0,
    ends_at: new Date(Date.now() + 7*24*60*60*1000).toISOString(),
    created_at: new Date().toISOString(),
    created_by: 1,
    winner_id: null,
    drawn_at: null
  });
  save(db);
  console.log('✅ Database seeded with admin and sample sorteio');
}

module.exports = {
  get() { return db; },
  save() { save(db); },
  reload() { db = load(); return db; }
};
