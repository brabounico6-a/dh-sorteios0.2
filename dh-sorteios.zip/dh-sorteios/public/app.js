// DH SORTEIOS - Frontend App
const API = '';

let currentUser = null;
let currentMessages = [];
let selectedMsgId = null;
let adminUnlocked = false;

// ========== UTILS ==========
function toast(msg, isError = false) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast show' + (isError ? ' error' : '');
  setTimeout(() => el.classList.remove('show'), 3500);
}

async function api(path, options = {}) {
  const res = await fetch(API + path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Erro na requisição');
  return data;
}

function formatDate(str) {
  if (!str) return '';
  const d = new Date(str);
  return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

// ========== AUTH ==========
document.querySelectorAll('.auth-tabs .tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.auth-tabs .tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const isLogin = tab.dataset.tab === 'login';
    document.getElementById('login-form').style.display = isLogin ? 'block' : 'none';
    document.getElementById('register-form').style.display = isLogin ? 'none' : 'block';
    document.getElementById('auth-error').textContent = '';
  });
});

document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('auth-error');
  errEl.textContent = '';
  try {
    const data = await api('/api/login', {
      method: 'POST',
      body: JSON.stringify({
        username: document.getElementById('login-username').value,
        password: document.getElementById('login-password').value
      })
    });
    currentUser = data.user;
    showApp();
  } catch (err) {
    errEl.textContent = err.message;
  }
});

document.getElementById('register-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = document.getElementById('auth-error');
  errEl.textContent = '';
  try {
    const data = await api('/api/register', {
      method: 'POST',
      body: JSON.stringify({
        username: document.getElementById('reg-username').value,
        password: document.getElementById('reg-password').value,
        displayName: document.getElementById('reg-displayname').value
      })
    });
    currentUser = data.user;
    toast('Conta criada com sucesso! Bem-vindo!');
    showApp();
  } catch (err) {
    errEl.textContent = err.message;
  }
});

document.getElementById('logout-btn').addEventListener('click', async () => {
  await api('/api/logout', { method: 'POST' });
  currentUser = null;
  adminUnlocked = false;
  document.getElementById('main-app').style.display = 'none';
  document.getElementById('auth-screen').style.display = 'flex';
});

// ========== NAVIGATION ==========
function showPage(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.side-item, .nav-item').forEach(i => i.classList.remove('active'));
  
  const pageEl = document.getElementById('page-' + page);
  if (pageEl) pageEl.classList.add('active');
  
  document.querySelectorAll(`[data-page="${page}"]`).forEach(el => el.classList.add('active'));

  if (page === 'sorteios') loadSorteios();
  if (page === 'inbox') loadInbox();
  if (page === 'historico') loadHistorico();
  if (page === 'ranking') loadRanking();
  if (page === 'perfil') loadProfile();
  if (page === 'admin') loadAdmin();
  if (page === 'inicio') loadHome();
}

document.querySelectorAll('[data-page]').forEach(btn => {
  btn.addEventListener('click', () => showPage(btn.dataset.page));
});

document.getElementById('notif-bell').addEventListener('click', () => showPage('inbox'));
document.getElementById('user-chip').addEventListener('click', () => showPage('perfil'));

// ========== SHOW APP ==========
async function showApp() {
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('main-app').style.display = 'block';
  
  try {
    const me = await api('/api/me');
    if (!me.authenticated) {
      document.getElementById('main-app').style.display = 'none';
      document.getElementById('auth-screen').style.display = 'flex';
      return;
    }
    currentUser = me.user;
    updateHeader();
    loadHome();
    loadUnread();
    
    // Show admin btn always (PIN protects)
    document.getElementById('admin-btn').style.display = 'flex';
  } catch (e) {
    console.error(e);
  }
}

function updateHeader() {
  if (!currentUser) return;
  document.getElementById('header-username').textContent = currentUser.displayName || currentUser.username;
  document.getElementById('header-id').textContent = currentUser.id;
}

async function loadUnread() {
  try {
    const data = await api('/api/inbox');
    const badge = document.getElementById('unread-badge');
    if (data.unread > 0) {
      badge.style.display = 'flex';
      badge.textContent = data.unread > 9 ? '9+' : data.unread;
    } else {
      badge.style.display = 'none';
    }
  } catch (e) {}
}

// ========== HOME ==========
async function loadHome() {
  try {
    const me = await api('/api/me');
    if (me.authenticated) {
      currentUser = me.user;
      document.getElementById('stat-parts').textContent = me.user.stats?.participations || 0;
      document.getElementById('stat-wins').textContent = me.user.stats?.wins || 0;
      document.getElementById('stat-points').textContent = me.user.points || 0;
    }
    
    const data = await api('/api/sorteios');
    const container = document.getElementById('home-sorteios');
    const active = data.sorteios.filter(s => s.status === 'active').slice(0, 3);
    if (active.length === 0) {
      container.innerHTML = '<p style="color:var(--text-dim)">Nenhum sorteio ativo no momento. Volte em breve!</p>';
      return;
    }
    container.innerHTML = active.map(s => renderSorteioCard(s)).join('');
    bindParticipateButtons();
  } catch (e) {
    console.error(e);
  }
}

// ========== SORTEIOS ==========
async function loadSorteios() {
  try {
    const data = await api('/api/sorteios');
    const container = document.getElementById('sorteios-list');
    if (!data.sorteios.length) {
      container.innerHTML = '<p style="color:var(--text-dim)">Nenhum sorteio disponível.</p>';
      return;
    }
    container.innerHTML = data.sorteios.map(s => renderSorteioCard(s)).join('');
    bindParticipateButtons();
  } catch (e) {
    toast(e.message, true);
  }
}

function renderSorteioCard(s) {
  const statusClass = s.status === 'active' ? 'active' : 'drawn';
  const statusText = s.status === 'active' ? 'Ativo' : (s.status === 'drawn' ? 'Sorteado' : 'Encerrado');
  
  let action = '';
  if (s.status === 'active') {
    if (s.already_participated) {
      action = `<button class="btn-participate" disabled>✓ Você já participou</button>`;
    } else {
      action = `<button class="btn-participate" data-id="${s.id}">Participar Agora</button>`;
    }
  } else if (s.winner_username) {
    action = `<div class="winner-badge">🏆 Ganhador: ${s.winner_username}</div>`;
  }

  return `
    <div class="sorteio-card">
      <span class="status ${statusClass}">${statusText}</span>
      <h3>${escapeHtml(s.title)}</h3>
      <div class="prize">🎁 ${escapeHtml(s.prize_name)}</div>
      <div class="desc">${escapeHtml(s.description || '')}</div>
      <div class="meta">
        <span>👥 ${s.participants_count || 0} participantes</span>
        ${s.ends_at ? `<span>⏰ ${formatDate(s.ends_at)}</span>` : ''}
      </div>
      ${action}
    </div>
  `;
}

function bindParticipateButtons() {
  document.querySelectorAll('.btn-participate[data-id]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      btn.disabled = true;
      btn.textContent = 'Participando...';
      try {
        await api(`/api/sorteios/${id}/participate`, { method: 'POST' });
        toast('Participação confirmada! Boa sorte! 🍀');
        loadSorteios();
        loadHome();
        loadUnread();
      } catch (err) {
        toast(err.message, true);
        btn.disabled = false;
        btn.textContent = 'Participar Agora';
      }
    });
  });
}

// ========== INBOX ==========
async function loadInbox() {
  try {
    const data = await api('/api/inbox');
    currentMessages = data.messages;
    const list = document.getElementById('inbox-messages');
    
    if (!data.messages.length) {
      list.innerHTML = `
        <div style="padding:40px 20px;text-align:center;color:var(--text-dim)">
          <div style="font-size:2rem;margin-bottom:8px">📭</div>
          Nenhuma mensagem ainda.<br>
          <small>Quando você ganhar, a conta chega aqui!</small>
        </div>`;
      return;
    }
    
    list.innerHTML = data.messages.map(m => `
      <div class="msg-item ${m.is_read ? '' : 'unread'} ${selectedMsgId == m.id ? 'active' : ''}" data-id="${m.id}">
        <div class="msg-icon">${m.is_prize ? '🏆' : '📩'}</div>
        <div class="msg-body">
          <div class="msg-from">${escapeHtml(m.sender)}</div>
          <div class="msg-subject">${escapeHtml(m.subject || m.content.slice(0, 40))}</div>
          <div class="msg-time">${formatDate(m.created_at)}</div>
        </div>
      </div>
    `).join('');
    
    list.querySelectorAll('.msg-item').forEach(item => {
      item.addEventListener('click', () => openMessage(item.dataset.id));
    });
    
    // Update badge
    const badge = document.getElementById('unread-badge');
    if (data.unread > 0) {
      badge.style.display = 'flex';
      badge.textContent = data.unread > 9 ? '9+' : data.unread;
    } else badge.style.display = 'none';
  } catch (e) {
    toast(e.message, true);
  }
}

async function openMessage(id) {
  selectedMsgId = id;
  const m = currentMessages.find(x => x.id == id);
  if (!m) return;
  
  // Mark read
  if (!m.is_read) {
    await api(`/api/inbox/${id}/read`, { method: 'POST' });
    m.is_read = 1;
  }
  
  const detail = document.getElementById('inbox-detail');
  detail.innerHTML = `
    <div class="detail-header">
      <div>
        <h3>${escapeHtml(m.subject || 'Mensagem')}</h3>
        <small style="color:var(--text-dim)">De: ${escapeHtml(m.sender)} • ${formatDate(m.created_at)}</small>
      </div>
      <button class="btn-secondary" style="padding:6px 12px;font-size:0.85rem" onclick="deleteMsg(${id})">🗑️ Excluir</button>
    </div>
    <div class="detail-content ${m.is_prize ? 'prize' : ''}">${escapeHtml(m.content)}</div>
  `;
  
  // Refresh list highlight
  loadInbox();
}

async function deleteMsg(id) {
  await api(`/api/inbox/${id}`, { method: 'DELETE' });
  selectedMsgId = null;
  document.getElementById('inbox-detail').innerHTML = `
    <div class="empty-detail">
      <div class="empty-icon">💬</div>
      <p>Selecione uma mensagem para ler</p>
    </div>`;
  loadInbox();
  toast('Mensagem excluída');
}

// ========== HISTORICO ==========
async function loadHistorico() {
  try {
    const data = await api('/api/historico');
    const list = document.getElementById('historico-list');
    if (!data.historico.length) {
      list.innerHTML = '<p style="color:var(--text-dim)">Você ainda não participou de nenhum sorteio.</p>';
      return;
    }
    list.innerHTML = data.historico.map(h => `
      <div class="list-item">
        <div>
          <strong>${escapeHtml(h.title)}</strong><br>
          <small style="color:var(--text-dim)">Prêmio: ${escapeHtml(h.prize_name)} • ${formatDate(h.participated_at)}</small>
        </div>
        <div>
          ${h.i_won ? '<span class="won">🏆 VOCÊ GANHOU!</span>' : 
            (h.status === 'drawn' ? '<span style="color:var(--text-dim)">Não foi dessa vez</span>' : 
            '<span style="color:var(--blue-bright)">Em andamento</span>')}
        </div>
      </div>
    `).join('');
  } catch (e) {
    toast(e.message, true);
  }
}

// ========== RANKING ==========
async function loadRanking() {
  try {
    const data = await api('/api/ranking');
    const list = document.getElementById('ranking-list');
    list.innerHTML = `
      <div class="rank-row">
        <div>#</div><div>JOGADOR</div><div>PONTOS</div><div>WINS</div>
      </div>
      ${data.ranking.map((u, i) => `
        <div class="rank-row ${i===0?'top1':i===1?'top2':i===2?'top3':''}">
          <div class="rank-pos">${i+1}</div>
          <div>${escapeHtml(u.display_name || u.username)}</div>
          <div style="color:var(--blue-bright)">${u.points}</div>
          <div>${u.wins || 0}</div>
        </div>
      `).join('')}
    `;
  } catch (e) {
    toast(e.message, true);
  }
}

// ========== PROFILE ==========
function loadProfile() {
  if (!currentUser) return;
  document.getElementById('prof-name').textContent = currentUser.displayName || currentUser.username;
  document.getElementById('prof-id').textContent = currentUser.id;
  document.getElementById('prof-user').textContent = currentUser.username;
  document.getElementById('prof-parts').textContent = currentUser.stats?.participations || 0;
  document.getElementById('prof-wins').textContent = currentUser.stats?.wins || 0;
  document.getElementById('prof-points').textContent = currentUser.points || 0;
}

// ========== ADMIN ==========
document.getElementById('verify-pin-btn').addEventListener('click', async () => {
  const pin = document.getElementById('admin-pin-input').value;
  const errEl = document.getElementById('pin-error');
  errEl.textContent = '';
  try {
    await api('/api/admin/verify-pin', {
      method: 'POST',
      body: JSON.stringify({ pin })
    });
    adminUnlocked = true;
    document.getElementById('admin-pin-box').style.display = 'none';
    document.getElementById('admin-panel').style.display = 'block';
    toast('Acesso admin liberado!');
    loadAdminSorteios();
  } catch (err) {
    errEl.textContent = err.message;
  }
});

document.getElementById('create-sorteio-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/api/admin/sorteios', {
      method: 'POST',
      body: JSON.stringify({
        title: document.getElementById('s-title').value,
        description: document.getElementById('s-desc').value,
        prize_name: document.getElementById('s-prize').value,
        prize_details: document.getElementById('s-details').value,
        ends_at: document.getElementById('s-ends').value || null
      })
    });
    toast('Sorteio criado com sucesso!');
    e.target.reset();
    loadAdminSorteios();
    loadSorteios();
  } catch (err) {
    toast(err.message, true);
  }
});

async function loadAdmin() {
  if (adminUnlocked) {
    document.getElementById('admin-pin-box').style.display = 'none';
    document.getElementById('admin-panel').style.display = 'block';
    loadAdminSorteios();
  } else {
    document.getElementById('admin-pin-box').style.display = 'block';
    document.getElementById('admin-panel').style.display = 'none';
  }
}

async function loadAdminSorteios() {
  try {
    const data = await api('/api/admin/sorteios');
    const list = document.getElementById('admin-sorteios-list');
    if (!data.sorteios.length) {
      list.innerHTML = '<p style="color:var(--text-dim)">Nenhum sorteio criado ainda.</p>';
      return;
    }
    list.innerHTML = data.sorteios.map(s => `
      <div class="admin-sorteio-item">
        <div class="info">
          <h4>${escapeHtml(s.title)}</h4>
          <span>🎁 ${escapeHtml(s.prize_name)} • 👥 ${s.participants_count} participantes • Status: ${s.status}</span>
          ${s.winner_username ? `<br><span style="color:var(--success)">🏆 Ganhador: ${s.winner_username}</span>` : ''}
        </div>
        <div>
          ${s.status === 'active' ? `
            <button class="btn-primary" style="width:auto;padding:8px 16px;font-size:0.85rem" 
              onclick="drawWinner(${s.id}, '${escapeHtml(s.prize_name)}')">
              🎲 Sortear Agora
            </button>
          ` : '<span style="color:var(--text-dim)">Finalizado</span>'}
        </div>
      </div>
    `).join('');
  } catch (e) {
    if (e.message.includes('admin')) {
      adminUnlocked = false;
      loadAdmin();
    }
  }
}

async function drawWinner(id, prizeName) {
  const details = prompt(`Digite os dados da conta/prêmio que serão enviados ao ganhador de "${prizeName}":\n\n(Login, senha, etc.)`);
  if (details === null) return;
  
  try {
    const data = await api(`/api/admin/sorteios/${id}/draw`, {
      method: 'POST',
      body: JSON.stringify({ prize_details: details })
    });
    toast(`🎉 Ganhador: ${data.winner.displayName || data.winner.username}`);
    loadAdminSorteios();
    loadSorteios();
  } catch (err) {
    toast(err.message, true);
  }
}

// ========== HELPERS ==========
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ========== INIT ==========
(async function init() {
  try {
    const me = await api('/api/me');
    if (me.authenticated) {
      currentUser = me.user;
      showApp();
    }
  } catch (e) {
    // not logged in
  }
})();
